**To get a client certificate**

Command::

  aws apigateway get-client-certificate --client-certificate-id a1b2c3
